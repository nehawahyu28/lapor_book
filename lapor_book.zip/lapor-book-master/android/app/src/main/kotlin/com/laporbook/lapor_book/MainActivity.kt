package com.laporbook.lapor_book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
